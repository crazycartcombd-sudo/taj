import React, { useState } from 'react';
import ReactDOM from 'react-dom/client';
import { MerchantAdminDashboard } from '../components/MerchantAdminDashboard';
import { QuickOrderCodModal } from '../components/QuickOrderCodModal';

const DEFAULT_STORE_ID =
  (import.meta as unknown as { env?: Record<string, string> }).env
    ?.VITE_CRAZY_CART_STORE_ID ?? '00000000-0000-4000-8000-000000000101';

const AppShell: React.FC = () => {
  const [quickOrderOpen, setQuickOrderOpen] = useState<boolean>(false);

  return (
    <>
      <div className="border-b border-slate-200 bg-slate-900 text-white">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-2 px-4 py-2.5 text-xs">
          <div className="font-semibold">
            Crazy Cart • Inside Dhaka ৳70 • Outside Dhaka ৳130 • bKash / Nagad /
            Rocket / COD
          </div>
          <button
            type="button"
            onClick={() => setQuickOrderOpen(true)}
            className="rounded-lg bg-indigo-500 px-3 py-1.5 font-extrabold text-white hover:bg-indigo-400"
          >
            Test 1-Click COD Modal (৳1,650)
          </button>
        </div>
      </div>

      <MerchantAdminDashboard
        storeId={DEFAULT_STORE_ID}
        storeName="Crazy Cart"
      />

      <QuickOrderCodModal
        isOpen={quickOrderOpen}
        onClose={() => setQuickOrderOpen(false)}
        storeId={DEFAULT_STORE_ID}
        storeName="Crazy Cart"
        product={{
          id: 'prod-royal-blue-katan-kids',
          title: 'Ready to Wear Pre-Stitched Royal Blue Silk Katan Saree for Kids',
          priceBdt: 1650,
        }}
        insideDhakaFeeBdt={70}
        outsideDhakaFeeBdt={130}
      />
    </>
  );
};

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <AppShell />
  </React.StrictMode>
);
