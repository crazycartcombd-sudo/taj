#!/usr/bin/env sh
set -eu
export TZ="Asia/Dhaka"

BACKUP_DIR="${BACKUP_DIR:-/backups}"
RETENTION_DAYS="${RETENTION_DAYS:-14}"
PGHOST="${POSTGRES_HOST:-postgres}"
PGDATABASE="${POSTGRES_DB:-crazy_cart}"
PGUSER="${POSTGRES_USER:-postgres}"
export PGPASSWORD="${POSTGRES_PASSWORD:-postgres}"

mkdir -p "$BACKUP_DIR"

STAMP="$(TZ='Asia/Dhaka' date '+%Y-%m-%d_%H%M%S_BDT')"
OUT_FILE="${BACKUP_DIR}/${PGDATABASE}_${STAMP}.sql.gz"

pg_dump -h "$PGHOST" -U "$PGUSER" -d "$PGDATABASE" --no-owner --no-privileges | gzip -9 > "$OUT_FILE"

find "$BACKUP_DIR" -type f -name "${PGDATABASE}_*.sql.gz" -mtime +"$RETENTION_DAYS" -delete

echo "[Asia/Dhaka] Backup completed: $OUT_FILE"
