import express, { NextFunction, Request, Response } from 'express';
import { Pool } from 'pg';
import { createDailySettlementSummaryRouter } from './routes/dailySettlementSummary';
import { createCourierCredentialsConnectionTestRouter } from './routes/courierCredentialsConnectionTest';
import { createCourierReturnRestockRouter } from './routes/courierReturnRestock';
import { createCarrierHandoverManifestRouter } from './routes/carrierHandoverManifest';
import { createFakeOrderReviewQueueRouter } from './routes/fakeOrderReviewQueue';
import { createWhatsAppAbandonedCheckoutRouter } from './routes/whatsappAbandonedCheckoutSender';
import { createMfsSmsForwarderWebhookRouter } from './routes/mfsSmsForwarderWebhook';
import { createBulkCatalogCsvImporterRouter } from './routes/bulkCatalogCsvImporter';
import { createFakeOrderGuardMiddleware } from './services/fakeOrderGuard';
import { StoreCourierCredentialVault } from './services/courierCredentialVault';
import { CourierDispatchWorker } from './services/courierDispatchWorker';
import { createCourierAdapter } from './services/courierAdapters';

const PORT = Number(process.env.PORT ?? 4000);
const DATABASE_URL =
  process.env.DATABASE_URL ??
  'postgresql://postgres:postgres@127.0.0.1:5432/crazy_cart';

export const db = new Pool({ connectionString: DATABASE_URL });

export function createCrazyCartApp(pool: Pool = db) {
  const app = express();
  app.use(express.json({ limit: '5mb' }));
  app.use(express.urlencoded({ extended: true }));
  app.use(express.text({ type: ['text/csv', 'text/plain'], limit: '5mb' }));

  app.use(async (_req: Request, _res: Response, next: NextFunction) => {
    try {
      await pool.query("SET TIME ZONE 'Asia/Dhaka'");
      next();
    } catch (err) {
      next(err);
    }
  });

  app.get('/health', async (_req: Request, res: Response) => {
    const nowDhaka = new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Dhaka',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    }).format(new Date());

    res.json({
      ok: true,
      service: 'crazy-cart-api',
      timezone: 'Asia/Dhaka',
      timestampDhaka: nowDhaka,
    });
  });

  const codRiskGuard = createFakeOrderGuardMiddleware(pool, {
    highRiskThreshold: 55,
    criticalRiskThreshold: 75,
    highCodAmountThresholdBdt: 3500,
  });

  app.use('/api/v1/public/stores/:storeId/orders', codRiskGuard);
  app.use('/api/v1/public/stores/:storeId/quick-checkout', codRiskGuard);

  const credentialVault = new StoreCourierCredentialVault(pool, {
    encryptionSecret: process.env.COURIER_CREDENTIALS_ENC_KEY,
  });

  app.use(createDailySettlementSummaryRouter(pool));
  app.use(
    createCourierCredentialsConnectionTestRouter(pool, {
      credentialVault,
      encryptionSecret: process.env.COURIER_CREDENTIALS_ENC_KEY,
    })
  );
  app.use(createCourierReturnRestockRouter(pool));
  app.use(createCarrierHandoverManifestRouter(pool));
  app.use(createFakeOrderReviewQueueRouter(pool));
  app.use(createBulkCatalogCsvImporterRouter(pool));
  app.use(
    createWhatsAppAbandonedCheckoutRouter(pool, {
      phoneNumberId: process.env.WHATSAPP_PHONE_NUMBER_ID ?? '',
      accessToken: process.env.WHATSAPP_CLOUD_API_TOKEN ?? '',
      templateName: process.env.WHATSAPP_ABANDONED_TEMPLATE_NAME ?? 'abandoned_checkout_bdt_v1',
      storefrontBaseUrl: process.env.STOREFRONT_BASE_URL ?? 'https://crazycart.com.bd',
    })
  );
  app.use(
    createMfsSmsForwarderWebhookRouter(pool, {
      webhookSecret: process.env.MFS_SMS_WEBHOOK_SECRET ?? '',
    })
  );

  app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
    res.status(500).json({
      ok: false,
      error: (err as Error)?.message || 'Internal server error in Crazy Cart API.',
    });
  });

  return app;
}

if (require.main === module) {
  const app = createCrazyCartApp(db);
  const dispatchWorker = new CourierDispatchWorker(db, {
    pollIntervalMs: 15000,
    batchSize: 15,
    encryptionSecret: process.env.COURIER_CREDENTIALS_ENC_KEY,
    dispatcher: async ({
      orderId,
      orderNumber,
      carrier,
      credentials,
      recipientName,
      recipientPhone,
      recipientAddress,
      codAmountBdt,
    }) => {
      const adapter = createCourierAdapter(carrier, credentials);
      const created = await adapter.createParcel({
        orderId,
        orderNumber,
        recipientName,
        recipientPhone,
        recipientAddress,
        codAmountBdt,
        totalUnits: 1,
        itemDescription: `Crazy Cart Order ${orderNumber}`,
      });
      return {
        consignmentId: created.consignmentId,
        trackingCode: created.trackingCode,
      };
    },
  });

  const server = app.listen(PORT, () => {
    console.log(`Crazy Cart API listening on http://0.0.0.0:${PORT} (Asia/Dhaka)`);
    if (process.env.ENABLE_COURIER_DISPATCH_WORKER !== 'false') {
      dispatchWorker.start();
    }
  });

  const shutdown = async () => {
    dispatchWorker.stop();
    server.close(async () => {
      await db.end().catch(() => {});
      process.exit(0);
    });
  };

  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}
