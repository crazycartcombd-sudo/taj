# Crazy Cart — Bangladesh D2C & F-Commerce Platform

Production-ready commerce operations stack tailored for Bangladesh (`Asia/Dhaka` `+06`, `BDT` `৳`, `+8801XXXXXXXXX`):
- **1-Click COD Quick Order Modal** (`Inside Dhaka ৳70`, `Outside Dhaka ৳130`) + **Prefilled Recovery Checkout**
- **MFS SMS Forwarder TrxID Webhook** with HMAC-SHA256 verification (`bKash`, `Nagad`, `Rocket`)
- **Per-Store AES-256-GCM Courier Credential Vault** & **Courier Dispatch Worker** (`Steadfast`, `Pathao`, `RedX`)
- **Fake Order Guard** risk scoring, **Return & Restock Queue**, **Carrier Handover Manifest** (UTF-8 BOM CSV), **Daily Settlement Dashboard**, and **80mm POS / 4x6 Label Print Center**
- **Docker Compose + GitHub Actions CI/CD** with daily `Asia/Dhaka` PostgreSQL backup rotation
