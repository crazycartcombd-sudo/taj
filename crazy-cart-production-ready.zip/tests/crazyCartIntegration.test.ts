import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import http from 'node:http';
import { Pool } from 'pg';
import { createCrazyCartApp } from '../server';
import { FakeOrderGuardService } from '../services/fakeOrderGuard';
import {
  CarrierHandoverManifestService,
  CarrierHandoverManifest,
} from '../services/carrierHandoverManifest';
import { verifyHmacSignature } from '../routes/mfsSmsForwarderWebhook';

function createMockPgPool() {
  const fakeClient = {
    query: async () => ({ rows: [] }),
    release: () => {},
  };
  return {
    connect: async () => fakeClient,
    query: async () => ({ rows: [] }),
    end: async () => {},
  } as unknown as Pool;
}

async function runTests() {
  const pool = createMockPgPool();
  const guard = new FakeOrderGuardService(pool);
  const risk = await guard.evaluateOrderRisk({
    storeId: '22222222-2222-4222-8222-222222222222',
    customerPhone: '+8801712345678',
    shippingAddress: 'na',
    paymentMethod: 'cod',
    totalAmountBdt: 4200,
  });
  assert.equal(risk.flagged, true);
  assert.equal(risk.currency, 'BDT');

  const manifestSvc = new CarrierHandoverManifestService(pool);
  const sampleManifest: CarrierHandoverManifest = {
    storeId: '22222222-2222-4222-8222-222222222222',
    storeName: 'Crazy Cart',
    timezone: 'Asia/Dhaka',
    manifestDateDhaka: '2026-11-22',
    generatedAtDhaka: '22 Nov 2026, 04:51:00 AM BDT (+06)',
    currency: 'BDT',
    summary: {
      totalParcels: 1,
      totalUnits: 1,
      grossOrderValueBdt: 1780,
      totalAdvancePaidBdt: 0,
      totalCodAmountBdt: 1780,
      totalDeliveryFeeBdt: 130,
    },
    groups: [
      {
        carrier: 'steadfast',
        label: 'Steadfast Courier',
        parcelCount: 1,
        totalUnits: 1,
        grossOrderValueBdt: 1780,
        advancePaidBdt: 0,
        totalCodAmountBdt: 1780,
        totalDeliveryFeeBdt: 130,
        parcels: [
          {
            orderId: '11111111-1111-4111-8111-111111111111',
            orderNumber: 'CC-1001',
            carrier: 'steadfast',
            consignmentId: 'SF-55001',
            trackingCode: 'SF-55001',
            customerName: 'Nusrat Jahan',
            customerPhone: '01712345678',
            shippingAddress: 'GEC Circle, Chattogram',
            deliveryZone: 'outside_dhaka',
            totalAmountBdt: 1780,
            advancePaidBdt: 0,
            codAmountBdt: 1780,
            deliveryFeeBdt: 130,
            itemSummary: 'Kids Silk Katan Saree x1',
            totalUnits: 1,
            dispatchedAtDhaka: '22 Nov 2026, 04:10 AM BDT (+06)',
          },
        ],
      },
    ],
    flatParcels: [],
  };
  const csvWithBom = manifestSvc.exportUtf8BomCsv(sampleManifest);
  assert.ok(csvWithBom.startsWith('\uFEFF'));

  process.env.MFS_SMS_WEBHOOK_SECRET = 'crazy-cart-sms-secret';
  const payload = JSON.stringify({
    sender: 'bKash',
    message: 'You have received Tk 1,650.00 from 01712345678. TrxID 9B4K7L2X1M',
  });
  const sig = crypto.createHmac('sha256', 'crazy-cart-sms-secret').update(payload).digest('hex');
  assert.equal(verifyHmacSignature(payload, sig, 'crazy-cart-sms-secret'), true);

  const app = createCrazyCartApp(pool);
  const server = http.createServer(app);
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve));
  const addr = server.address();
  const port = typeof addr === 'object' && addr ? addr.port : 0;
  const healthRes = await fetch(`http://127.0.0.1:${port}/health`);
  const healthJson = (await healthRes.json()) as { ok: boolean; timezone: string };
  assert.equal(healthJson.ok, true);
  assert.equal(healthJson.timezone, 'Asia/Dhaka');
  server.close();
  console.log('All Crazy Cart integration checks passed.');
}

void runTests();
