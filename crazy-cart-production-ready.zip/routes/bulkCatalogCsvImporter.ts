import { NextFunction, Request, Response, Router } from 'express';
import { Pool } from 'pg';
import { BulkCatalogCsvImporter } from '../services/bulkCatalogCsvImporter';

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export function createBulkCatalogCsvImporterRouter(db: Pool) {
  const router = Router();
  const importer = new BulkCatalogCsvImporter(db);
  router.post('/api/v1/admin/stores/:storeId/catalog/import-csv', async (req: Request, res: Response, next: NextFunction) => {
    const storeId = String(req.params.storeId ?? '').trim();
    if (!storeId || !UUID_REGEX.test(storeId)) {
      return res.status(400).json({ error: 'Valid storeId (UUID) is required.' });
    }
    const csvPayload =
      typeof req.body === 'string' ? req.body : String(req.body?.csv ?? req.body?.content ?? '').trim();
    if (!csvPayload) {
      return res.status(400).json({ error: 'CSV payload is required.' });
    }
    try {
      const summary = await importer.importCsv(storeId, csvPayload);
      return res.json(summary);
    } catch (err) {
      return next(err);
    }
  });
  return router;
}
