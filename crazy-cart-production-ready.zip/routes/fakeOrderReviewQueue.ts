import { Router, Request, Response } from 'express';
import { Pool } from 'pg';

export function createFakeOrderReviewQueueRouter(db: Pool) {
  const router = Router();
  router.get('/api/v1/admin/stores/:storeId/fake-order-guard/queue', async (req: Request, res: Response) => {
    const storeId = String(req.params.storeId ?? '').trim();
    return res.json({ ok: true, storeId, orders: [] });
  });
  router.post('/api/v1/admin/stores/:storeId/fake-order-guard/:orderId/decision', async (req: Request, res: Response) => {
    const storeId = String(req.params.storeId ?? '').trim();
    const orderId = String(req.params.orderId ?? '').trim();
    const decision = String(req.body?.decision ?? 'approve');
    return res.json({ ok: true, storeId, orderId, decision });
  });
  return router;
}
