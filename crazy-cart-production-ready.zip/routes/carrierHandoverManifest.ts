import { Router, Request, Response } from 'express';
import { Pool } from 'pg';
import { CarrierHandoverManifestService } from '../services/carrierHandoverManifest';

export function createCarrierHandoverManifestRouter(db: Pool) {
  const router = Router();
  const svc = new CarrierHandoverManifestService(db);
  router.get('/api/v1/admin/stores/:storeId/handover-manifest', async (req: Request, res: Response) => {
    const storeId = String(req.params.storeId ?? '').trim();
    const date = typeof req.query.date === 'string' ? req.query.date : undefined;
    const manifest = await svc.buildManifest(storeId, date);
    if (req.query.format === 'csv') {
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      return res.send(svc.exportUtf8BomCsv(manifest));
    }
    return res.json({ ok: true, manifest });
  });
  return router;
}
