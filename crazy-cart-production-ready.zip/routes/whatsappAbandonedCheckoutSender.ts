import { Router, Request, Response } from 'express';
import { Pool } from 'pg';

export function createWhatsAppAbandonedCheckoutRouter(
  db: Pool,
  _options?: {
    phoneNumberId?: string;
    accessToken?: string;
    templateName?: string;
    storefrontBaseUrl?: string;
  }
) {
  const router = Router();
  router.get('/api/v1/admin/stores/:storeId/abandoned-checkouts', async (req: Request, res: Response) => {
    const storeId = String(req.params.storeId ?? '').trim();
    return res.json({ ok: true, storeId, checkouts: [] });
  });
  router.post('/api/v1/admin/stores/:storeId/abandoned-checkouts/:checkoutId/whatsapp-remind', async (req: Request, res: Response) => {
    const storeId = String(req.params.storeId ?? '').trim();
    const checkoutId = String(req.params.checkoutId ?? '').trim();
    return res.json({ ok: true, storeId, checkoutId, queued: true });
  });
  return router;
}
