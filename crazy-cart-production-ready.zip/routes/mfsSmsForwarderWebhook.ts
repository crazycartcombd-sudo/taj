import crypto from 'crypto';
import { NextFunction, Request, Response, Router } from 'express';
import { Pool } from 'pg';

export type MfsProviderKey = 'bkash' | 'nagad' | 'rocket';

export interface ParsedMfsSms {
  channel: MfsProviderKey | null;
  trxId: string | null;
  amountBdt: number | null;
  senderAccount: string | null;
}

export function verifyHmacSignature(
  rawBody: string | Buffer,
  signatureHeader: unknown,
  secret: string
): boolean {
  if (!secret || typeof signatureHeader !== 'string') return false;
  const trimmedSig = signatureHeader.trim().replace(/^sha256=/i, '').toLowerCase();
  if (!/^[0-9a-f]{64}$/.test(trimmedSig)) return false;

  const expectedHex = crypto
    .createHmac('sha256', secret)
    .update(rawBody)
    .digest('hex')
    .toLowerCase();

  const sigBuf = Buffer.from(trimmedSig, 'hex');
  const expBuf = Buffer.from(expectedHex, 'hex');
  if (sigBuf.length !== expBuf.length) return false;
  return crypto.timingSafeEqual(sigBuf, expBuf);
}

export function parseMfsSmsMessage(smsText: string, senderHint?: string): ParsedMfsSms {
  const combined = `${senderHint ?? ''} ${smsText ?? ''}`.trim().toLowerCase();
  let channel: MfsProviderKey | null = null;
  if (combined.includes('bkash')) channel = 'bkash';
  else if (combined.includes('nagad')) channel = 'nagad';
  else if (combined.includes('rocket') || combined.includes('dbbl')) channel = 'rocket';

  const trxMatch = smsText.match(/\b(?:TrxID|TxnID|Trx\s*ID|Transaction\s*ID)[:\s#-]*([A-Z0-9]{6,16})\b/i);
  const trxId = trxMatch ? trxMatch[1].trim().toUpperCase() : null;

  const amtMatch =
    smsText.match(/\b(?:Tk\.?|BDT|Taka)\s*([0-9,]+(?:\.[0-9]{1,2})?)\b/i) ??
    smsText.match(/\b([0-9,]+(?:\.[0-9]{1,2})?)\s*(?:Tk\.?|BDT|Taka)\b/i);

  let amountBdt: number | null = null;
  if (amtMatch) {
    const cleaned = Number(amtMatch[1].replace(/,/g, ''));
    if (Number.isFinite(cleaned) && cleaned > 0) amountBdt = Math.round(cleaned);
  }

  const phoneMatch = smsText.match(/\b(01[3-9]\d{8})\b/);
  return {
    channel,
    trxId,
    amountBdt,
    senderAccount: phoneMatch ? phoneMatch[1] : null,
  };
}

export function createMfsSmsForwarderWebhookRouter(
  db: Pool,
  options?: { webhookSecret?: string }
) {
  const router = Router();
  const webhookSecret = options?.webhookSecret ?? process.env.MFS_SMS_WEBHOOK_SECRET ?? '';

  router.post(
    '/api/v1/webhooks/mfs-sms-forwarder',
    async (req: Request, res: Response, next: NextFunction) => {
      if (!webhookSecret) {
        return res.status(503).json({ ok: false, error: 'MFS SMS webhook secret is not configured.' });
      }
      const rawBodyStr = JSON.stringify(req.body ?? {});
      const sigHeader =
        req.headers['x-cc-signature-256'] ??
        req.headers['x-signature-256'] ??
        req.headers['x-hub-signature-256'];

      if (!verifyHmacSignature(rawBodyStr, sigHeader, webhookSecret)) {
        return res.status(401).json({ ok: false, error: 'Invalid HMAC signature.' });
      }

      const body = (req.body ?? {}) as Record<string, unknown>;
      const message = String(body.message ?? body.sms ?? body.body ?? '').trim();
      const sender = String(body.sender ?? body.from ?? '').trim();
      const storeId =
        typeof body.storeId === 'string' && body.storeId.trim() ? body.storeId.trim() : null;

      if (!message) {
        return res.status(400).json({ ok: false, error: 'SMS message body is required.' });
      }

      const parsed = parseMfsSmsMessage(message, sender);
      if (!parsed.trxId) {
        return res.status(422).json({ ok: false, error: 'Could not extract TrxID.', parsed });
      }

      const client = await db.connect();
      try {
        await client.query('BEGIN');
        await client.query("SET TIME ZONE 'Asia/Dhaka'");
        const matchRes = await client.query<{
          id: string;
          order_number: string;
          total_amount_bdt: string;
          advance_paid_bdt: string;
        }>(
          `
          SELECT id, COALESCE(order_number, id::text) AS order_number,
                 COALESCE(total_amount_bdt, 0)::text AS total_amount_bdt,
                 COALESCE(advance_paid_bdt, 0)::text AS advance_paid_bdt
          FROM orders
          WHERE ($1::uuid IS NULL OR store_id = $1::uuid)
            AND UPPER(COALESCE(mfs_trx_id, '')) = $2
          FOR UPDATE LIMIT 1
          `,
          [storeId, parsed.trxId]
        );
        if (matchRes.rows.length === 0) {
          await client.query('COMMIT');
          return res.status(202).json({ ok: true, matched: false, parsed });
        }
        const orderRow = matchRes.rows[0];
        const orderTotalBdt = Math.round(Number(orderRow.total_amount_bdt ?? 0));
        const creditedBdt = parsed.amountBdt && parsed.amountBdt > 0 ? parsed.amountBdt : orderTotalBdt;
        const isFullPayment = creditedBdt >= orderTotalBdt && orderTotalBdt > 0;

        await client.query(
          `
          UPDATE orders
          SET mfs_verified = TRUE,
              mfs_channel = COALESCE($2, mfs_channel),
              advance_paid_bdt = GREATEST(COALESCE(advance_paid_bdt, 0), $3),
              payment_method = CASE WHEN $4::boolean THEN 'paid_mfs' ELSE payment_method END,
              order_status = CASE WHEN LOWER(COALESCE(order_status, '')) IN ('pending', 'awaiting_advance') THEN 'confirmed' ELSE order_status END,
              updated_at = NOW()
          WHERE id = $1::uuid
          `,
          [orderRow.id, parsed.channel, creditedBdt, isFullPayment]
        );
        await client.query('COMMIT');
        return res.json({
          ok: true,
          matched: true,
          orderId: orderRow.id,
          orderNumber: orderRow.order_number,
          trxId: parsed.trxId,
          channel: parsed.channel,
          creditedAmountBdt: creditedBdt,
          fullPaymentSettled: isFullPayment,
        });
      } catch (err) {
        await client.query('ROLLBACK').catch(() => {});
        return next(err);
      } finally {
        client.release();
      }
    }
  );
  return router;
}
