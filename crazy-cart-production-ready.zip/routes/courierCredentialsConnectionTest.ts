import { Router, Request, Response } from 'express';
import { Pool } from 'pg';
import { CourierCarrierKey, StoreCourierCredentialVault } from '../services/courierCredentialVault';
import { createCourierAdapter } from '../services/courierAdapters';

export function createCourierCredentialsConnectionTestRouter(
  db: Pool,
  options?: { credentialVault?: StoreCourierCredentialVault; encryptionSecret?: string }
) {
  const router = Router();
  const vault =
    options?.credentialVault ??
    new StoreCourierCredentialVault(db, { encryptionSecret: options?.encryptionSecret });

  router.put('/api/v1/admin/stores/:storeId/courier-vault/:carrier', async (req: Request, res: Response) => {
    const storeId = String(req.params.storeId ?? '').trim();
    const carrier = String(req.params.carrier ?? '').trim().toLowerCase() as CourierCarrierKey;
    const creds = (req.body?.credentials ?? req.body ?? {}) as Record<string, string>;
    await vault.upsertCredentials(storeId, carrier, creds);
    return res.json({ ok: true, storeId, carrier, saved: true });
  });

  router.post('/api/v1/admin/stores/:storeId/courier-vault/:carrier/test', async (req: Request, res: Response) => {
    const storeId = String(req.params.storeId ?? '').trim();
    const carrier = String(req.params.carrier ?? '').trim().toLowerCase() as CourierCarrierKey;
    const creds = await vault.getDecryptedCredentials(storeId, carrier);
    if (!creds) {
      return res.status(404).json({ ok: false, error: 'No credentials stored in vault for carrier.' });
    }
    const adapter = createCourierAdapter(carrier, creds);
    const probe = await adapter.testConnection();
    return res.json({ ok: probe.ok, result: probe });
  });

  return router;
}
