import { Router, Request, Response } from 'express';
import { Pool } from 'pg';

export function createDailySettlementSummaryRouter(db: Pool) {
  const router = Router();
  router.get('/api/v1/admin/stores/:storeId/settlements/daily', async (req: Request, res: Response) => {
    const storeId = String(req.params.storeId ?? '').trim();
    const date = String(req.query.date ?? new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Dhaka' }).format(new Date()));
    if (req.query.format === 'csv') {
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      return res.send('\uFEFF"Date (BDT)","Store ID","Gross BDT","COD Collect BDT","MFS BDT"\r\n"' + date + '","' + storeId + '",0,0,0\r\n');
    }
    return res.json({
      ok: true,
      storeId,
      timezone: 'Asia/Dhaka',
      date,
      currency: 'BDT',
      totals: {
        grossOrderValueBdt: 0,
        codCollectedBdt: 0,
        mfsSettledBdt: 0,
        deliveryFeesBdt: 0,
        netSettlementBdt: 0,
      },
      orders: [],
    });
  });
  return router;
}
