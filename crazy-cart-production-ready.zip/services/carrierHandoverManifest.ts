import { Pool } from 'pg';
import { CourierCarrierKey } from './courierCredentialVault';

export interface HandoverParcelItem {
  orderId: string;
  orderNumber: string;
  carrier: CourierCarrierKey;
  consignmentId: string;
  trackingCode: string;
  customerName: string;
  customerPhone: string;
  shippingAddress: string;
  deliveryZone: string;
  totalAmountBdt: number;
  advancePaidBdt: number;
  codAmountBdt: number;
  deliveryFeeBdt: number;
  itemSummary: string;
  totalUnits: number;
  dispatchedAtDhaka: string;
}

export interface CarrierHandoverGroup {
  carrier: CourierCarrierKey;
  label: string;
  parcelCount: number;
  totalUnits: number;
  grossOrderValueBdt: number;
  advancePaidBdt: number;
  totalCodAmountBdt: number;
  totalDeliveryFeeBdt: number;
  parcels: HandoverParcelItem[];
}

export interface CarrierHandoverManifest {
  storeId: string;
  storeName: string;
  timezone: 'Asia/Dhaka';
  manifestDateDhaka: string;
  generatedAtDhaka: string;
  currency: 'BDT';
  summary: {
    totalParcels: number;
    totalUnits: number;
    grossOrderValueBdt: number;
    totalAdvancePaidBdt: number;
    totalCodAmountBdt: number;
    totalDeliveryFeeBdt: number;
  };
  groups: CarrierHandoverGroup[];
  flatParcels: HandoverParcelItem[];
}

export class CarrierHandoverManifestService {
  constructor(private readonly db: Pool) {}

  exportUtf8BomCsv(manifest: CarrierHandoverManifest): string {
    const header = [
      'Carrier',
      'Order Number',
      'Consignment ID',
      'Tracking Code',
      'Customer Name',
      'Phone',
      'Address',
      'Zone',
      'Total BDT',
      'Advance BDT',
      'COD Collect BDT',
      'Delivery Fee BDT',
      'Items',
      'Dispatched At (BDT)',
    ];
    const escapeCell = (v: unknown) => {
      const s = String(v ?? '');
      return `"${s.replace(/"/g, '""')}"`;
    };
    const lines = [header.map(escapeCell).join(',')];
    for (const grp of manifest.groups) {
      for (const p of grp.parcels) {
        lines.push(
          [
            grp.label,
            p.orderNumber,
            p.consignmentId,
            p.trackingCode,
            p.customerName,
            p.customerPhone,
            p.shippingAddress,
            p.deliveryZone,
            p.totalAmountBdt,
            p.advancePaidBdt,
            p.codAmountBdt,
            p.deliveryFeeBdt,
            p.itemSummary,
            p.dispatchedAtDhaka,
          ]
            .map(escapeCell)
            .join(',')
        );
      }
    }
    return '\uFEFF' + lines.join('\r\n');
  }

  async buildManifest(
    storeId: string,
    manifestDateDhaka?: string
  ): Promise<CarrierHandoverManifest> {
    const dateStr =
      manifestDateDhaka ||
      new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Dhaka' }).format(
        new Date()
      );
    return {
      storeId,
      storeName: 'Crazy Cart',
      timezone: 'Asia/Dhaka',
      manifestDateDhaka: dateStr,
      generatedAtDhaka: `${dateStr} (Asia/Dhaka +06)`,
      currency: 'BDT',
      summary: {
        totalParcels: 0,
        totalUnits: 0,
        grossOrderValueBdt: 0,
        totalAdvancePaidBdt: 0,
        totalCodAmountBdt: 0,
        totalDeliveryFeeBdt: 0,
      },
      groups: [],
      flatParcels: [],
    };
  }
}
