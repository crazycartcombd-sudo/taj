import { CourierCarrierKey } from './courierCredentialVault';

export interface CourierParcelDispatchRequest {
  orderId: string;
  orderNumber: string;
  recipientName: string;
  recipientPhone: string;
  recipientAddress: string;
  deliveryZone?: string | null;
  codAmountBdt: number;
  totalUnits: number;
  itemDescription: string;
}

export interface CourierParcelDispatchResponse {
  carrier: CourierCarrierKey;
  consignmentId: string;
  trackingCode: string;
  rawStatus?: string;
}

export interface CourierConnectionProbeResult {
  carrier: CourierCarrierKey;
  ok: boolean;
  latencyMs: number;
  message: string;
}

function normalizePhone01(raw: string): string {
  const digits = String(raw ?? '').replace(/\D/g, '');
  if (digits.startsWith('880') && digits.length === 13) {
    return digits.slice(2);
  }
  return digits;
}

function roundBdt(val: number): number {
  return Number.isFinite(val) && val > 0 ? Math.round(val) : 0;
}

async function fetchWithTimeout(
  url: string,
  init: RequestInit,
  timeoutMs = 8000
): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

export class SteadfastCourierAdapter {
  private readonly baseUrl: string;
  private readonly apiKey: string;
  private readonly secretKey: string;

  constructor(credentials: Record<string, string>) {
    this.baseUrl = (
      credentials.base_url ||
      credentials.baseUrl ||
      'https://portal.packzy.com/api/v1'
    ).replace(/\/+$/, '');
    this.apiKey = (credentials.api_key || credentials.apiKey || '').trim();
    this.secretKey = (
      credentials.secret_key ||
      credentials.secretKey ||
      ''
    ).trim();
  }

  private headers(): Record<string, string> {
    return {
      'Api-Key': this.apiKey,
      'Secret-Key': this.secretKey,
      'Content-Type': 'application/json',
      Accept: 'application/json',
    };
  }

  async testConnection(): Promise<CourierConnectionProbeResult> {
    const start = Date.now();
    try {
      const res = await fetchWithTimeout(`${this.baseUrl}/get_balance`, {
        method: 'GET',
        headers: this.headers(),
      });
      const latencyMs = Date.now() - start;
      return {
        carrier: 'steadfast',
        ok: res.ok,
        latencyMs,
        message: res.ok
          ? 'Connected to Steadfast Courier API.'
          : `Steadfast probe failed (HTTP ${res.status}).`,
      };
    } catch (err) {
      return {
        carrier: 'steadfast',
        ok: false,
        latencyMs: Date.now() - start,
        message: (err as Error)?.message || 'Steadfast connection error.',
      };
    }
  }

  async createParcel(
    req: CourierParcelDispatchRequest
  ): Promise<CourierParcelDispatchResponse> {
    const res = await fetchWithTimeout(`${this.baseUrl}/create_order`, {
      method: 'POST',
      headers: this.headers(),
      body: JSON.stringify({
        invoice: req.orderNumber,
        recipient_name: req.recipientName,
        recipient_phone: normalizePhone01(req.recipientPhone),
        recipient_address: req.recipientAddress,
        cod_amount: roundBdt(req.codAmountBdt),
        item_description: req.itemDescription,
        note: `Crazy Cart Order ${req.orderNumber}`,
      }),
    });
    const data = (await res.json().catch(() => null)) as any;
    if (!res.ok) {
      throw new Error(data?.message || `Steadfast create_order failed (${res.status})`);
    }
    const consignmentId = String(
      data?.consignment?.consignment_id ?? data?.consignment_id ?? `SF-${req.orderNumber}`
    );
    return {
      carrier: 'steadfast',
      consignmentId,
      trackingCode: String(data?.consignment?.tracking_code ?? data?.tracking_code ?? consignmentId),
      rawStatus: data?.consignment?.status ?? data?.status,
    };
  }
}

export class PathaoCourierAdapter {
  private readonly baseUrl: string;
  private readonly accessToken: string;
  private readonly storeId: string;

  constructor(credentials: Record<string, string>) {
    this.baseUrl = (
      credentials.base_url ||
      credentials.baseUrl ||
      'https://api-hermes.pathao.com'
    ).replace(/\/+$/, '');
    this.accessToken = (
      credentials.access_token ||
      credentials.accessToken ||
      credentials.api_key ||
      ''
    ).trim();
    this.storeId = (
      credentials.store_id ||
      credentials.pathao_store_id ||
      credentials.storeId ||
      ''
    ).trim();
  }

  private headers(): Record<string, string> {
    return {
      Authorization: `Bearer ${this.accessToken}`,
      'Content-Type': 'application/json',
      Accept: 'application/json',
    };
  }

  async testConnection(): Promise<CourierConnectionProbeResult> {
    const start = Date.now();
    try {
      const res = await fetchWithTimeout(`${this.baseUrl}/aladdin/api/v1/stores`, {
        method: 'GET',
        headers: this.headers(),
      });
      return {
        carrier: 'pathao',
        ok: res.ok,
        latencyMs: Date.now() - start,
        message: res.ok ? 'Connected to Pathao Courier API.' : `Pathao probe failed (${res.status})`,
      };
    } catch (err) {
      return {
        carrier: 'pathao',
        ok: false,
        latencyMs: Date.now() - start,
        message: (err as Error)?.message || 'Pathao connection error.',
      };
    }
  }

  async createParcel(
    req: CourierParcelDispatchRequest
  ): Promise<CourierParcelDispatchResponse> {
    const res = await fetchWithTimeout(`${this.baseUrl}/aladdin/api/v1/orders`, {
      method: 'POST',
      headers: this.headers(),
      body: JSON.stringify({
        store_id: this.storeId ? Number(this.storeId) || this.storeId : undefined,
        merchant_order_id: req.orderNumber,
        recipient_name: req.recipientName,
        recipient_phone: normalizePhone01(req.recipientPhone),
        recipient_address: req.recipientAddress,
        delivery_type: 48,
        item_type: 2,
        item_quantity: Math.max(1, req.totalUnits),
        amount_to_collect: roundBdt(req.codAmountBdt),
        item_description: req.itemDescription,
      }),
    });
    const data = (await res.json().catch(() => null)) as any;
    if (!res.ok) {
      throw new Error(data?.message || `Pathao order failed (${res.status})`);
    }
    const consignmentId = String(
      data?.data?.consignment_id ?? data?.consignment_id ?? `PT-${req.orderNumber}`
    );
    return {
      carrier: 'pathao',
      consignmentId,
      trackingCode: consignmentId,
      rawStatus: data?.data?.order_status ?? data?.order_status,
    };
  }
}

export class RedXCourierAdapter {
  private readonly baseUrl: string;
  private readonly apiToken: string;

  constructor(credentials: Record<string, string>) {
    this.baseUrl = (
      credentials.base_url ||
      credentials.baseUrl ||
      'https://openapi.redx.com.bd/v1.0.0-beta'
    ).replace(/\/+$/, '');
    this.apiToken = (
      credentials.api_token ||
      credentials.access_token ||
      credentials.api_key ||
      ''
    ).trim();
  }

  private headers(): Record<string, string> {
    return {
      Authorization: `Bearer ${this.apiToken}`,
      'API-ACCESS-TOKEN': `Bearer ${this.apiToken}`,
      'Content-Type': 'application/json',
      Accept: 'application/json',
    };
  }

  async testConnection(): Promise<CourierConnectionProbeResult> {
    const start = Date.now();
    try {
      const res = await fetchWithTimeout(`${this.baseUrl}/pickup/stores`, {
        method: 'GET',
        headers: this.headers(),
      });
      return {
        carrier: 'redx',
        ok: res.ok,
        latencyMs: Date.now() - start,
        message: res.ok ? 'Connected to RedX Logistics API.' : `RedX probe failed (${res.status})`,
      };
    } catch (err) {
      return {
        carrier: 'redx',
        ok: false,
        latencyMs: Date.now() - start,
        message: (err as Error)?.message || 'RedX connection error.',
      };
    }
  }

  async createParcel(
    req: CourierParcelDispatchRequest
  ): Promise<CourierParcelDispatchResponse> {
    const res = await fetchWithTimeout(`${this.baseUrl}/parcel`, {
      method: 'POST',
      headers: this.headers(),
      body: JSON.stringify({
        customer_name: req.recipientName,
        customer_phone: normalizePhone01(req.recipientPhone),
        delivery_area: req.deliveryZone || 'Bangladesh',
        customer_address: req.recipientAddress,
        merchant_invoice_id: req.orderNumber,
        cash_collection_amount: String(roundBdt(req.codAmountBdt)),
        parcel_weight: Math.max(500, req.totalUnits * 500),
        instruction: req.itemDescription,
      }),
    });
    const data = (await res.json().catch(() => null)) as any;
    if (!res.ok) {
      throw new Error(data?.message || `RedX parcel failed (${res.status})`);
    }
    const trackingCode = String(
      data?.tracking_id ?? data?.data?.tracking_id ?? `RX-${req.orderNumber}`
    );
    return {
      carrier: 'redx',
      consignmentId: trackingCode,
      trackingCode,
      rawStatus: data?.status ?? 'created',
    };
  }
}

export function createCourierAdapter(
  carrier: CourierCarrierKey,
  credentials: Record<string, string>
) {
  switch (carrier) {
    case 'steadfast':
      return new SteadfastCourierAdapter(credentials);
    case 'pathao':
      return new PathaoCourierAdapter(credentials);
    case 'redx':
      return new RedXCourierAdapter(credentials);
  }
}
