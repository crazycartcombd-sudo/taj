import { Pool } from 'pg';

export interface ParsedCatalogCsvRow {
  rowNumber: number;
  category: string;
  subcategory: string | null;
  sku: string | null;
  title: string;
  priceBdt: number;
  stockQuantity: number;
}

export interface BulkCatalogImportSummary {
  ok: boolean;
  storeId: string;
  totalRowsParsed: number;
  importedCount: number;
  updatedCount: number;
  skippedCount: number;
  currency: 'BDT';
  importedAtDhaka: string;
  errors: Array<{ rowNumber: number; reason: string }>;
}

function splitCsvLine(line: string): string[] {
  const cells: string[] = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i += 1) {
    const ch = line[i];
    if (ch === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i += 1;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (ch === ',' && !inQuotes) {
      cells.push(current.trim());
      current = '';
    } else {
      current += ch;
    }
  }
  cells.push(current.trim());
  return cells;
}

export function parseBulkCatalogCsv(csvText: string): {
  rows: ParsedCatalogCsvRow[];
  errors: Array<{ rowNumber: number; reason: string }>;
} {
  const stripped = csvText.replace(/^\uFEFF/, '');
  const rawLines = stripped
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0);

  const rows: ParsedCatalogCsvRow[] = [];
  const errors: Array<{ rowNumber: number; reason: string }> = [];

  if (rawLines.length === 0) return { rows, errors };

  const firstCells = splitCsvLine(rawLines[0]).map((c) => c.toLowerCase());
  const hasHeader =
    firstCells.includes('title') ||
    firstCells.includes('product_title') ||
    firstCells.includes('price_bdt') ||
    firstCells.includes('category');

  const headerMap = new Map<string, number>();
  if (hasHeader) {
    firstCells.forEach((col, idx) => headerMap.set(col, idx));
  }

  const getCol = (cells: string[], names: string[], fallbackIdx: number) => {
    for (const name of names) {
      const idx = headerMap.get(name);
      if (idx !== undefined && idx < cells.length) return cells[idx];
    }
    return fallbackIdx < cells.length ? cells[fallbackIdx] : '';
  };

  const startIndex = hasHeader ? 1 : 0;
  for (let i = startIndex; i < rawLines.length; i += 1) {
    const rowNumber = i + 1;
    const cells = splitCsvLine(rawLines[i]);
    const category = getCol(cells, ['category', 'main_category'], 0) || 'Apparel';
    const subcategory = getCol(cells, ['subcategory', 'sub_category'], 1) || null;
    const sku = getCol(cells, ['sku', 'product_sku', 'code'], 2) || null;
    const title = getCol(cells, ['title', 'product_title', 'name', 'product_name'], 3);
    const rawPrice = getCol(cells, ['price_bdt', 'price', 'amount_bdt', 'bdt'], 4).replace(/[৳,\s]/g, '');
    const rawStock = getCol(cells, ['stock_quantity', 'stock', 'qty', 'quantity'], 5).replace(/[,\s]/g, '');

    if (!title) {
      errors.push({ rowNumber, reason: 'Missing product title.' });
      continue;
    }
    const priceBdt = Number(rawPrice);
    if (!Number.isFinite(priceBdt) || priceBdt < 0) {
      errors.push({ rowNumber, reason: `Invalid BDT price ("${rawPrice}") for "${title}".` });
      continue;
    }
    const stockQuantity = rawStock === '' ? 0 : Math.max(0, Math.round(Number(rawStock)));
    if (!Number.isFinite(stockQuantity)) {
      errors.push({ rowNumber, reason: `Invalid stock quantity ("${rawStock}") for "${title}".` });
      continue;
    }

    rows.push({
      rowNumber,
      category: category.trim(),
      subcategory: subcategory ? subcategory.trim() : null,
      sku: sku ? sku.trim().toUpperCase() : null,
      title: title.trim(),
      priceBdt: Math.round(priceBdt),
      stockQuantity,
    });
  }

  return { rows, errors };
}

export class BulkCatalogCsvImporter {
  constructor(private readonly db: Pool) {}

  async importCsv(storeId: string, csvText: string): Promise<BulkCatalogImportSummary> {
    const importedAtDhaka = `${new Intl.DateTimeFormat('en-GB', {
      timeZone: 'Asia/Dhaka',
      year: 'numeric',
      month: 'short',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
    }).format(new Date())} BDT (+06)`;

    const { rows, errors } = parseBulkCatalogCsv(csvText);
    let importedCount = 0;
    let updatedCount = 0;

    const client = await this.db.connect();
    try {
      await client.query('BEGIN');
      await client.query("SET TIME ZONE 'Asia/Dhaka'");
      for (const item of rows) {
        if (item.sku) {
          const existing = await client.query<{ id: string }>(
            `SELECT id FROM products WHERE store_id = $1::uuid AND UPPER(COALESCE(sku, '')) = $2 LIMIT 1`,
            [storeId, item.sku]
          );
          if (existing.rows.length > 0) {
            await client.query(
              `UPDATE products SET title = $2, price_bdt = $3, stock_quantity = $4, updated_at = NOW() WHERE id = $1::uuid`,
              [existing.rows[0].id, item.title, item.priceBdt, item.stockQuantity]
            );
            updatedCount += 1;
            continue;
          }
        }
        await client.query(
          `INSERT INTO products (store_id, sku, title, price_bdt, stock_quantity, is_active) VALUES ($1::uuid, $2, $3, $4, $5, TRUE)`,
          [storeId, item.sku, item.title, item.priceBdt, item.stockQuantity]
        );
        importedCount += 1;
      }
      await client.query('COMMIT');
    } catch (err) {
      await client.query('ROLLBACK').catch(() => {});
      throw err;
    } finally {
      client.release();
    }

    return {
      ok: true,
      storeId,
      totalRowsParsed: rows.length + errors.length,
      importedCount,
      updatedCount,
      skippedCount: errors.length,
      currency: 'BDT',
      importedAtDhaka,
      errors,
    };
  }
}
