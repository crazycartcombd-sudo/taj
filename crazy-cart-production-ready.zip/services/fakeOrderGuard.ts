import { NextFunction, Request, Response } from 'express';
import { Pool } from 'pg';

export interface FakeOrderRiskEvaluation {
  riskScore: number;
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  flagged: boolean;
  currency: 'BDT';
  reasons: string[];
}

export class FakeOrderGuardService {
  constructor(
    private readonly db: Pool,
    private readonly config?: {
      highRiskThreshold?: number;
      criticalRiskThreshold?: number;
      highCodAmountThresholdBdt?: number;
    }
  ) {}

  async evaluateOrderRisk(input: {
    storeId: string;
    customerPhone: string;
    shippingAddress: string;
    paymentMethod?: string;
    totalAmountBdt?: number;
  }): Promise<FakeOrderRiskEvaluation> {
    const reasons: string[] = [];
    let score = 0;

    const cleanPhone = String(input.customerPhone ?? '').replace(/\D/g, '');
    const cleanAddr = String(input.shippingAddress ?? '').trim().toLowerCase();
    const codThreshold = this.config?.highCodAmountThresholdBdt ?? 3500;
    const highThresh = this.config?.highRiskThreshold ?? 55;
    const critThresh = this.config?.criticalRiskThreshold ?? 75;

    if (!/^01[3-9]\d{8}$/.test(cleanPhone.slice(-11))) {
      score += 35;
      reasons.push('Non-standard Bangladesh mobile format');
    }

    if (cleanAddr.length < 10 || ['na', 'n/a', 'test', 'dhaka'].includes(cleanAddr)) {
      score += 35;
      reasons.push('Incomplete or placeholder delivery address');
    }

    if (
      String(input.paymentMethod ?? 'cod').toLowerCase() === 'cod' &&
      Number(input.totalAmountBdt ?? 0) >= codThreshold
    ) {
      score += 20;
      reasons.push(`High COD order value (>= ৳${codThreshold})`);
    }

    const client = await this.db.connect();
    try {
      const hist = await client.query<{
        total_cnt: string;
        returned_cnt: string;
        last_1h_cnt: string;
      }>(
        `
        SELECT
          COUNT(*)::text AS total_cnt,
          COUNT(*) FILTER (WHERE LOWER(COALESCE(order_status, '')) IN ('returned', 'cancelled'))::text AS returned_cnt,
          COUNT(*) FILTER (WHERE created_at >= NOW() - INTERVAL '1 hour')::text AS last_1h_cnt
        FROM orders
        WHERE store_id = $1::uuid
          AND regexp_replace(COALESCE(customer_phone, ''), '\D', '', 'g') LIKE '%' || RIGHT($2, 11)
        `,
        [input.storeId, cleanPhone.slice(-11)]
      );
      const row = hist.rows[0];
      const retCnt = Number(row?.returned_cnt ?? 0);
      const last1h = Number(row?.last_1h_cnt ?? 0);
      if (retCnt > 0) {
        score += Math.min(40, retCnt * 20);
        reasons.push(`Previous returned/cancelled orders (${retCnt})`);
      }
      if (last1h >= 2) {
        score += 25;
        reasons.push('Rapid duplicate orders within 1 hour');
      }
    } catch {
      // Ignore history lookup error when DB table is empty/mocked
    } finally {
      client.release();
    }

    const bounded = Math.min(100, Math.max(0, score));
    const riskLevel: FakeOrderRiskEvaluation['riskLevel'] =
      bounded >= critThresh
        ? 'critical'
        : bounded >= highThresh
          ? 'high'
          : bounded >= 30
            ? 'medium'
            : 'low';

    return {
      riskScore: bounded,
      riskLevel,
      flagged: bounded >= highThresh,
      currency: 'BDT',
      reasons,
    };
  }
}

export function createFakeOrderGuardMiddleware(
  db: Pool,
  config?: {
    highRiskThreshold?: number;
    criticalRiskThreshold?: number;
    highCodAmountThresholdBdt?: number;
  }
) {
  const service = new FakeOrderGuardService(db, config);
  return async (req: Request, _res: Response, next: NextFunction) => {
    try {
      const storeId = String(req.params.storeId ?? req.body?.storeId ?? '').trim();
      const customerPhone = String(req.body?.customerPhone ?? '');
      const shippingAddress = String(req.body?.shippingAddress ?? '');
      const paymentMethod = String(req.body?.paymentMethod ?? 'cod');
      const totalAmountBdt = Number(req.body?.totalAmountBdt ?? 0);
      if (storeId && customerPhone) {
        (req as any).fakeOrderGuardResult = await service.evaluateOrderRisk({
          storeId,
          customerPhone,
          shippingAddress,
          paymentMethod,
          totalAmountBdt,
        });
      }
      next();
    } catch (err) {
      next(err);
    }
  };
}
