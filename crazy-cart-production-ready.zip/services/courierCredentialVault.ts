import crypto from 'crypto';
import { Pool } from 'pg';

export type CourierCarrierKey = 'steadfast' | 'pathao' | 'redx';

export class StoreCourierCredentialVault {
  private readonly key: Buffer;

  constructor(
    private readonly db: Pool,
    options?: { encryptionSecret?: string }
  ) {
    const secret =
      options?.encryptionSecret ||
      process.env.COURIER_CREDENTIALS_ENC_KEY ||
      'dev-crazy-cart-vault-secret-key-2026';
    this.key = crypto.createHash('sha256').update(secret).digest();
  }

  encryptObject(payload: Record<string, string>): {
    encryptedPayload: string;
    iv: string;
    authTag: string;
  } {
    const iv = crypto.randomBytes(12);
    const cipher = crypto.createCipheriv('aes-256-gcm', this.key, iv);
    const enc = Buffer.concat([
      cipher.update(JSON.stringify(payload), 'utf8'),
      cipher.final(),
    ]);
    const authTag = cipher.getAuthTag();
    return {
      encryptedPayload: enc.toString('base64'),
      iv: iv.toString('base64'),
      authTag: authTag.toString('base64'),
    };
  }

  decryptObject(
    encryptedPayload: string,
    ivB64: string,
    authTagB64: string
  ): Record<string, string> {
    const iv = Buffer.from(ivB64, 'base64');
    const authTag = Buffer.from(authTagB64, 'base64');
    const decipher = crypto.createDecipheriv('aes-256-gcm', this.key, iv);
    decipher.setAuthTag(authTag);
    const dec = Buffer.concat([
      decipher.update(Buffer.from(encryptedPayload, 'base64')),
      decipher.final(),
    ]);
    return JSON.parse(dec.toString('utf8')) as Record<string, string>;
  }

  async upsertCredentials(
    storeId: string,
    carrier: CourierCarrierKey,
    credentials: Record<string, string>
  ): Promise<void> {
    const { encryptedPayload, iv, authTag } = this.encryptObject(credentials);
    await this.db.query(
      `
      INSERT INTO store_courier_credential_vault
        (store_id, carrier, encrypted_payload, iv, auth_tag)
      VALUES ($1::uuid, $2, $3, $4, $5)
      ON CONFLICT (store_id, carrier)
      DO UPDATE SET
        encrypted_payload = EXCLUDED.encrypted_payload,
        iv = EXCLUDED.iv,
        auth_tag = EXCLUDED.auth_tag,
        updated_at = NOW()
      `,
      [storeId, carrier, encryptedPayload, iv, authTag]
    );
  }

  async getDecryptedCredentials(
    storeId: string,
    carrier: CourierCarrierKey
  ): Promise<Record<string, string> | null> {
    const res = await this.db.query<{
      encrypted_payload: string;
      iv: string;
      auth_tag: string;
    }>(
      `
      SELECT encrypted_payload, iv, auth_tag
      FROM store_courier_credential_vault
      WHERE store_id = $1::uuid AND carrier = $2
      LIMIT 1
      `,
      [storeId, carrier]
    );
    if (res.rows.length === 0) return null;
    const row = res.rows[0];
    return this.decryptObject(row.encrypted_payload, row.iv, row.auth_tag);
  }
}
