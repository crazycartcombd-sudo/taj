import { Pool } from 'pg';
import {
  CourierCarrierKey,
  StoreCourierCredentialVault,
} from './courierCredentialVault';

export interface CourierDispatchWorkerOptions {
  pollIntervalMs?: number;
  batchSize?: number;
  encryptionSecret?: string;
  dispatcher?: (params: {
    orderId: string;
    orderNumber: string;
    carrier: CourierCarrierKey;
    credentials: Record<string, string>;
    recipientName: string;
    recipientPhone: string;
    recipientAddress: string;
    codAmountBdt: number;
  }) => Promise<{ consignmentId: string; trackingCode?: string }>;
}

export interface DispatchBatchSummary {
  processedCount: number;
  dispatchedCount: number;
  failedCount: number;
  ranAtDhaka: string;
}

function normalizeCarrier(raw: unknown): CourierCarrierKey | null {
  const c = String(raw ?? '').trim().toLowerCase();
  if (c === 'steadfast' || c === 'sf') return 'steadfast';
  if (c === 'pathao' || c === 'pt') return 'pathao';
  if (c === 'redx' || c === 'rx') return 'redx';
  return null;
}

export class CourierDispatchWorker {
  private readonly pollIntervalMs: number;
  private readonly batchSize: number;
  private readonly vault: StoreCourierCredentialVault;
  private readonly dispatcher: NonNullable<
    CourierDispatchWorkerOptions['dispatcher']
  >;
  private timer: NodeJS.Timeout | null = null;
  private running = false;

  constructor(
    private readonly db: Pool,
    options?: CourierDispatchWorkerOptions
  ) {
    this.pollIntervalMs = options?.pollIntervalMs ?? 15000;
    this.batchSize = options?.batchSize ?? 15;
    this.vault = new StoreCourierCredentialVault(db, {
      encryptionSecret: options?.encryptionSecret,
    });
    this.dispatcher =
      options?.dispatcher ??
      (async ({ orderId, carrier }) => ({
        consignmentId: `${carrier.toUpperCase()}-${orderId.slice(0, 8).toUpperCase()}`,
        trackingCode: `${carrier.toUpperCase()}-${orderId.slice(0, 8).toUpperCase()}`,
      }));
  }

  async runOnce(): Promise<DispatchBatchSummary> {
    const ranAtDhaka = `${new Intl.DateTimeFormat('en-GB', {
      timeZone: 'Asia/Dhaka',
      year: 'numeric',
      month: 'short',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
    }).format(new Date())} BDT (+06)`;

    let dispatchedCount = 0;
    let failedCount = 0;

    const client = await this.db.connect();
    let candidateOrders: Array<{
      id: string;
      store_id: string;
      order_number: string;
      courier_provider: string | null;
      customer_name: string | null;
      customer_phone: string | null;
      shipping_address: string | null;
      payment_method: string | null;
      total_amount_bdt: string | null;
      advance_paid_bdt: string | null;
    }> = [];

    try {
      await client.query('BEGIN');
      await client.query("SET TIME ZONE 'Asia/Dhaka'");
      const res = await client.query<{
        id: string;
        store_id: string;
        order_number: string;
        courier_provider: string | null;
        customer_name: string | null;
        customer_phone: string | null;
        shipping_address: string | null;
        payment_method: string | null;
        total_amount_bdt: string | null;
        advance_paid_bdt: string | null;
      }>(
        `
        SELECT
          o.id,
          o.store_id,
          COALESCE(o.order_number, o.id::text) AS order_number,
          COALESCE(o.courier_provider, 'steadfast') AS courier_provider,
          COALESCE(o.customer_name, 'Customer') AS customer_name,
          COALESCE(o.customer_phone, '') AS customer_phone,
          COALESCE(o.shipping_address, '') AS shipping_address,
          COALESCE(o.payment_method, 'cod') AS payment_method,
          COALESCE(o.total_amount_bdt, 0)::text AS total_amount_bdt,
          COALESCE(o.advance_paid_bdt, 0)::text AS advance_paid_bdt
        FROM orders o
        WHERE LOWER(COALESCE(o.order_status, '')) = 'confirmed'
          AND COALESCE(o.fake_order_flagged, FALSE) = FALSE
          AND (o.courier_consignment_id IS NULL OR BTRIM(o.courier_consignment_id) = '')
        ORDER BY o.created_at ASC
        FOR UPDATE SKIP LOCKED
        LIMIT $1
        `,
        [this.batchSize]
      );
      candidateOrders = res.rows;
      await client.query('COMMIT');
    } catch (err) {
      await client.query('ROLLBACK').catch(() => {});
      throw err;
    } finally {
      client.release();
    }

    for (const order of candidateOrders) {
      const carrier = normalizeCarrier(order.courier_provider) ?? 'steadfast';
      try {
        const creds = await this.vault.getDecryptedCredentials(order.store_id, carrier);
        if (!creds) {
          throw new Error(`Missing ${carrier} vault credentials for store ${order.store_id}`);
        }
        const totalBdt = Math.max(0, Math.round(Number(order.total_amount_bdt ?? 0)));
        const advanceBdt = Math.max(0, Math.round(Number(order.advance_paid_bdt ?? 0)));
        const codAmountBdt =
          String(order.payment_method ?? 'cod').toLowerCase() === 'paid_mfs'
            ? 0
            : Math.max(0, totalBdt - advanceBdt);

        const dispatchRes = await this.dispatcher({
          orderId: order.id,
          orderNumber: order.order_number,
          carrier,
          credentials: creds,
          recipientName: String(order.customer_name ?? 'Customer'),
          recipientPhone: String(order.customer_phone ?? ''),
          recipientAddress: String(order.shipping_address ?? ''),
          codAmountBdt,
        });

        const updClient = await this.db.connect();
        try {
          await updClient.query("SET TIME ZONE 'Asia/Dhaka'");
          await updClient.query(
            `
            UPDATE orders
            SET
              courier_provider = $2,
              courier_consignment_id = $3,
              courier_tracking_code = $4,
              courier_status = 'in_transit',
              order_status = 'dispatched',
              courier_dispatched_at = NOW(),
              courier_updated_at = NOW(),
              updated_at = NOW()
            WHERE id = $1::uuid
            `,
            [
              order.id,
              carrier,
              dispatchRes.consignmentId,
              dispatchRes.trackingCode ?? dispatchRes.consignmentId,
            ]
          );
        } finally {
          updClient.release();
        }
        dispatchedCount += 1;
      } catch (err) {
        failedCount += 1;
        const errClient = await this.db.connect();
        try {
          await errClient.query("SET TIME ZONE 'Asia/Dhaka'");
          await errClient.query(
            `
            UPDATE orders
            SET courier_status_note = $2, courier_updated_at = NOW(), updated_at = NOW()
            WHERE id = $1::uuid
            `,
            [order.id, String((err as Error)?.message ?? 'Dispatch error').slice(0, 250)]
          );
        } finally {
          errClient.release();
        }
      }
    }

    return {
      processedCount: candidateOrders.length,
      dispatchedCount,
      failedCount,
      ranAtDhaka,
    };
  }

  start(): void {
    if (this.timer) return;
    const tick = async () => {
      if (this.running) return;
      this.running = true;
      try {
        await this.runOnce();
      } catch (err) {
        console.error('[CourierDispatchWorker] Tick error:', err);
      } finally {
        this.running = false;
      }
    };
    void tick();
    this.timer = setInterval(tick, this.pollIntervalMs);
  }

  stop(): void {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }
}
