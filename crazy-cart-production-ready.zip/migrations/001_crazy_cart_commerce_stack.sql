CREATE EXTENSION IF NOT EXISTS pgcrypto;
SET TIME ZONE 'Asia/Dhaka';

CREATE TABLE IF NOT EXISTS stores (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL DEFAULT 'Crazy Cart',
  slug TEXT UNIQUE,
  phone TEXT,
  address TEXT,
  inside_dhaka_fee_bdt INTEGER NOT NULL DEFAULT 70,
  outside_dhaka_fee_bdt INTEGER NOT NULL DEFAULT 130,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
  sku TEXT,
  title TEXT NOT NULL,
  price_bdt INTEGER NOT NULL DEFAULT 0,
  stock_quantity INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
  order_number TEXT NOT NULL,
  customer_name TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  shipping_address TEXT NOT NULL,
  delivery_zone TEXT NOT NULL DEFAULT 'outside_dhaka',
  payment_method TEXT NOT NULL DEFAULT 'cod',
  mfs_channel TEXT,
  mfs_trx_id TEXT,
  mfs_verified BOOLEAN NOT NULL DEFAULT FALSE,
  subtotal_bdt INTEGER NOT NULL DEFAULT 0,
  delivery_fee_bdt INTEGER NOT NULL DEFAULT 0,
  discount_bdt INTEGER NOT NULL DEFAULT 0,
  advance_paid_bdt INTEGER NOT NULL DEFAULT 0,
  total_amount_bdt INTEGER NOT NULL DEFAULT 0,
  order_status TEXT NOT NULL DEFAULT 'pending',
  courier_provider TEXT,
  courier_consignment_id TEXT,
  courier_tracking_code TEXT,
  courier_status TEXT,
  courier_status_note TEXT,
  courier_dispatched_at TIMESTAMPTZ,
  courier_updated_at TIMESTAMPTZ,
  inventory_restocked BOOLEAN NOT NULL DEFAULT FALSE,
  inventory_restocked_at TIMESTAMPTZ,
  fake_order_flagged BOOLEAN NOT NULL DEFAULT FALSE,
  fake_order_risk_score INTEGER NOT NULL DEFAULT 0,
  fake_order_risk_level TEXT NOT NULL DEFAULT 'low',
  fake_order_review_decision TEXT NOT NULL DEFAULT 'pending',
  client_ip TEXT,
  abandoned_checkout_id UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id UUID REFERENCES products(id) ON DELETE SET NULL,
  sku TEXT,
  product_title TEXT NOT NULL,
  quantity INTEGER NOT NULL DEFAULT 1,
  unit_price_bdt INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS abandoned_checkouts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
  customer_name TEXT,
  customer_phone TEXT,
  shipping_address TEXT,
  delivery_zone TEXT NOT NULL DEFAULT 'outside_dhaka',
  subtotal_bdt INTEGER NOT NULL DEFAULT 0,
  delivery_fee_bdt INTEGER NOT NULL DEFAULT 0,
  total_amount_bdt INTEGER NOT NULL DEFAULT 0,
  item_summary TEXT,
  preferred_mfs_channel TEXT,
  status TEXT NOT NULL DEFAULT 'abandoned',
  recovered_order_id UUID REFERENCES orders(id) ON DELETE SET NULL,
  recovered_at TIMESTAMPTZ,
  whatsapp_last_sent_at TIMESTAMPTZ,
  whatsapp_reminder_count INTEGER NOT NULL DEFAULT 0,
  whatsapp_last_message_id TEXT,
  whatsapp_last_mode TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS store_courier_credential_vault (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
  carrier TEXT NOT NULL,
  encrypted_payload TEXT NOT NULL,
  iv TEXT NOT NULL,
  auth_tag TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (store_id, carrier)
);

CREATE TABLE IF NOT EXISTS inventory_restock_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  courier_provider TEXT,
  consignment_id TEXT,
  restocked_units INTEGER NOT NULL DEFAULT 0,
  restocked_by_staff_id TEXT,
  note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO stores (id, name, slug, phone, address, inside_dhaka_fee_bdt, outside_dhaka_fee_bdt)
VALUES (
  '00000000-0000-4000-8000-000000000101',
  'Crazy Cart',
  'crazy-cart',
  '+8801711000000',
  'GEC Circle, Chattogram',
  70,
  130
)
ON CONFLICT (id) DO NOTHING;

INSERT INTO products (store_id, sku, title, price_bdt, stock_quantity, is_active)
SELECT
  '00000000-0000-4000-8000-000000000101'::uuid,
  'CC-KAT-RB-01',
  'Ready to Wear Pre-Stitched Royal Blue Silk Katan Saree for Kids',
  1650,
  25,
  TRUE
WHERE NOT EXISTS (
  SELECT 1 FROM products
  WHERE store_id = '00000000-0000-4000-8000-000000000101'::uuid
    AND sku = 'CC-KAT-RB-01'
);
