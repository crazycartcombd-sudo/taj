import React from 'react';
export interface PrintableOrderItem {
  id: string;
  title: string;
  sku?: string;
  quantity: number;
  unitPriceBdt: number;
}
export interface PrintableOrderRecord {
  orderId: string;
  orderNumber: string;
  customerName: string;
  customerPhone: string;
  shippingAddress: string;
  deliveryZone: string;
  paymentMethod: string;
  courierProvider?: string | null;
  consignmentId?: string | null;
  trackingCode?: string | null;
  subtotalBdt: number;
  deliveryFeeBdt: number;
  discountBdt: number;
  advancePaidBdt: number;
  totalAmountBdt: number;
  createdAtDhaka: string;
  items: PrintableOrderItem[];
}
export const PosAndLabelPrintSheet: React.FC<{ order: PrintableOrderRecord; storeName?: string }> = ({ order, storeName = 'Crazy Cart' }) => (
  <div className="rounded-2xl border border-slate-200 bg-white p-5">
    <h2 className="text-base font-extrabold text-slate-900">{storeName} — 80mm POS Receipt & 4×6 Waybill Print Center</h2>
    <p className="mt-1 text-xs text-slate-500">Order {order.orderNumber} • Collect ৳{order.totalAmountBdt.toLocaleString('en-BD')}</p>
  </div>
);
