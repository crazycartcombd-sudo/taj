import React, { useMemo, useState } from 'react';

export type DeliveryZoneKey = 'inside_dhaka' | 'outside_dhaka';

export interface QuickOrderProduct {
  id: string;
  title: string;
  priceBdt: number;
  imageUrl?: string | null;
}

interface QuickOrderCodModalProps {
  isOpen: boolean;
  onClose: () => void;
  storeId: string;
  storeName?: string;
  product: QuickOrderProduct;
  insideDhakaFeeBdt?: number;
  outsideDhakaFeeBdt?: number;
  abandonedCheckoutId?: string | null;
  onOrderCreated?: (result: {
    orderId: string;
    orderNumber: string;
    totalAmountBdt: number;
    fakeOrderFlagged?: boolean;
  }) => void;
}

function formatBdt(amount: number): string {
  const safe = Number.isFinite(amount) ? Math.round(amount) : 0;
  return `৳${safe.toLocaleString('en-BD')}`;
}

export const QuickOrderCodModal: React.FC<QuickOrderCodModalProps> = ({
  isOpen,
  onClose,
  storeId,
  storeName = 'Crazy Cart',
  product,
  insideDhakaFeeBdt = 70,
  outsideDhakaFeeBdt = 130,
  abandonedCheckoutId = null,
  onOrderCreated,
}) => {
  const [quantity, setQuantity] = useState<number>(1);
  const [deliveryZone, setDeliveryZone] = useState<DeliveryZoneKey>('inside_dhaka');
  const [customerName, setCustomerName] = useState<string>('');
  const [customerPhone, setCustomerPhone] = useState<string>('');
  const [shippingAddress, setShippingAddress] = useState<string>('');
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [createdOrder, setCreatedOrder] = useState<{
    orderNumber: string;
    totalAmountBdt: number;
    fakeOrderFlagged?: boolean;
  } | null>(null);

  const pricing = useMemo(() => {
    const qty = Math.max(1, Math.round(quantity));
    const subtotalBdt = qty * Math.max(0, Math.round(product.priceBdt));
    const deliveryFeeBdt =
      deliveryZone === 'inside_dhaka'
        ? Math.max(0, Math.round(insideDhakaFeeBdt))
        : Math.max(0, Math.round(outsideDhakaFeeBdt));
    return { qty, subtotalBdt, deliveryFeeBdt, totalAmountBdt: subtotalBdt + deliveryFeeBdt };
  }, [quantity, product.priceBdt, deliveryZone, insideDhakaFeeBdt, outsideDhakaFeeBdt]);

  if (!isOpen) return null;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setErrorMsg(null);
    setSubmitting(true);
    try {
      const res = await fetch(
        `/api/v1/public/stores/${encodeURIComponent(storeId)}/quick-checkout`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
          body: JSON.stringify({
            storeId,
            paymentMethod: 'cod',
            currency: 'BDT',
            customerName: customerName.trim(),
            customerPhone: customerPhone.trim(),
            shippingAddress: shippingAddress.trim(),
            deliveryZone,
            quantity: pricing.qty,
            subtotalBdt: pricing.subtotalBdt,
            deliveryFeeBdt: pricing.deliveryFeeBdt,
            totalAmountBdt: pricing.totalAmountBdt,
            abandonedCheckoutId: abandonedCheckoutId || undefined,
          }),
        }
      );
      const data = await res.json();
      if (!res.ok || !data?.ok) {
        throw new Error(data?.error || 'Could not place Cash on Delivery order.');
      }
      const orderNumber = String(data?.order?.orderNumber ?? data?.orderNumber ?? 'CC-COD');
      const orderId = String(data?.order?.id ?? data?.orderId ?? '');
      const totalBdt = Number(data?.order?.totalAmountBdt ?? pricing.totalAmountBdt);
      const flagged = Boolean(data?.fakeOrderGuard?.flagged ?? false);
      setCreatedOrder({ orderNumber, totalAmountBdt: totalBdt, fakeOrderFlagged: flagged });
      onOrderCreated?.({ orderId, orderNumber, totalAmountBdt: totalBdt, fakeOrderFlagged: flagged });
    } catch (err) {
      setErrorMsg((err as Error)?.message || 'Failed to submit COD order.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div role="dialog" aria-modal="true" className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
      <div className="w-full max-w-lg rounded-3xl bg-white p-6 shadow-2xl">
        <div className="flex items-start justify-between border-b border-slate-100 pb-3">
          <div>
            <span className="inline-flex rounded-full bg-indigo-50 px-2.5 py-0.5 text-[11px] font-bold text-indigo-700">
              {storeName} • Cash on Delivery (BDT)
            </span>
            <h3 className="mt-1 text-lg font-extrabold text-slate-900">1-Click COD Quick Order</h3>
          </div>
          <button type="button" onClick={onClose} className="rounded-xl border border-slate-200 px-2.5 py-1 text-xs font-bold text-slate-600">
            ✕
          </button>
        </div>

        {createdOrder ? (
          <div className="mt-4 space-y-4">
            <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-emerald-950">
              <div className="text-sm font-extrabold">Order Placed — {createdOrder.orderNumber}</div>
              <p className="mt-1 text-xs">Total COD: <strong>{formatBdt(createdOrder.totalAmountBdt)}</strong></p>
            </div>
            <button type="button" onClick={() => { setCreatedOrder(null); onClose(); }} className="w-full rounded-xl bg-slate-900 py-3 text-xs font-extrabold text-white">
              Done
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="mt-4 space-y-3">
            <div className="flex items-center justify-between rounded-2xl border border-slate-200 bg-slate-50 p-3">
              <div>
                <div className="text-xs font-extrabold text-slate-900">{product.title}</div>
                <div className="text-xs font-bold text-indigo-700">{formatBdt(product.priceBdt)} each</div>
              </div>
              <div className="flex items-center gap-1.5">
                <button type="button" onClick={() => setQuantity((q) => Math.max(1, q - 1))} className="h-8 w-8 rounded-lg border bg-white text-xs font-extrabold">−</button>
                <span className="w-6 text-center text-xs font-extrabold">{pricing.qty}</span>
                <button type="button" onClick={() => setQuantity((q) => Math.min(20, q + 1))} className="h-8 w-8 rounded-lg border bg-white text-xs font-extrabold">+</button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button type="button" onClick={() => setDeliveryZone('inside_dhaka')} className={`rounded-xl border p-2 text-left text-xs font-extrabold ${deliveryZone === 'inside_dhaka' ? 'border-indigo-600 bg-indigo-50' : 'border-slate-200'}`}>
                Inside Dhaka ({formatBdt(insideDhakaFeeBdt)})
              </button>
              <button type="button" onClick={() => setDeliveryZone('outside_dhaka')} className={`rounded-xl border p-2 text-left text-xs font-extrabold ${deliveryZone === 'outside_dhaka' ? 'border-indigo-600 bg-indigo-50' : 'border-slate-200'}`}>
                Outside Dhaka ({formatBdt(outsideDhakaFeeBdt)})
              </button>
            </div>

            <input type="text" required value={customerName} onChange={(e) => setCustomerName(e.target.value)} placeholder="Full Name" className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm" />
            <input type="tel" required value={customerPhone} onChange={(e) => setCustomerPhone(e.target.value)} placeholder="017XXXXXXXX" className="w-full rounded-xl border border-slate-300 px-3 py-2 font-mono text-sm" />
            <textarea rows={2} required value={shippingAddress} onChange={(e) => setShippingAddress(e.target.value)} placeholder="House, Road, Area / Thana, District" className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm" />

            <div className="flex justify-between border-t border-slate-200 pt-2 text-sm font-extrabold">
              <span>Pay on Delivery (COD)</span>
              <span className="text-indigo-700">{formatBdt(pricing.totalAmountBdt)}</span>
            </div>

            {errorMsg && <div className="rounded-xl bg-rose-50 p-2.5 text-xs font-semibold text-rose-700">{errorMsg}</div>}

            <button type="submit" disabled={submitting} className="w-full rounded-xl bg-indigo-600 py-3 text-sm font-extrabold text-white">
              {submitting ? 'Confirming...' : `Confirm COD Order • ${formatBdt(pricing.totalAmountBdt)}`}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
