import React from 'react';
export const AbandonedCartRecoveryConsole: React.FC<{ storeId: string; storeName?: string }> = ({ storeId, storeName = 'Crazy Cart' }) => (
  <div className="rounded-2xl border border-slate-200 bg-white p-5">
    <h2 className="text-base font-extrabold text-slate-900">{storeName} — Abandoned Checkout WhatsApp CRM</h2>
    <p className="mt-1 text-xs text-slate-500">Recovery reminders in BDT for store {storeId}</p>
  </div>
);
