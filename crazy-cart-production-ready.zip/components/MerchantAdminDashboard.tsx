import React, { useState } from 'react';
import { DailySettlementDashboard } from './DailySettlementDashboard';
import { CourierCredentialsSettingsPanel } from './CourierCredentialsSettingsPanel';
import { CourierReturnRestockConsole } from './CourierReturnRestockConsole';
import { CarrierHandoverManifestConsole } from './CarrierHandoverManifestConsole';
import { FakeOrderReviewConsole } from './FakeOrderReviewConsole';
import { AbandonedCartRecoveryConsole } from './AbandonedCartRecoveryConsole';
import { PrintableOrderRecord, PosAndLabelPrintSheet } from './PosAndLabelPrintSheet';

export type AdminTabKey =
  | 'settlement'
  | 'manifest'
  | 'returns'
  | 'fake_guard'
  | 'abandoned_crm'
  | 'courier_vault'
  | 'print_center';

const DEFAULT_PRINT_ORDER: PrintableOrderRecord = {
  orderId: '00000000-0000-4000-8000-000000000001',
  orderNumber: 'CC-20261122-1042',
  customerName: 'Nusrat Jahan',
  customerPhone: '01711-000000',
  shippingAddress: 'House 14, Road 7, GEC Circle, Chattogram',
  deliveryZone: 'outside_dhaka',
  paymentMethod: 'cod',
  courierProvider: 'steadfast',
  consignmentId: 'SF-9843120',
  trackingCode: 'SF-9843120',
  subtotalBdt: 1650,
  deliveryFeeBdt: 130,
  discountBdt: 0,
  advancePaidBdt: 0,
  totalAmountBdt: 1780,
  createdAtDhaka: '22 Nov 2026, 04:51 AM BDT (+06)',
  items: [
    {
      id: 'item-1',
      title: 'Ready to Wear Pre-Stitched Royal Blue Silk Katan Saree for Kids',
      sku: 'CC-KAT-RB-01',
      quantity: 1,
      unitPriceBdt: 1650,
    },
  ],
};

export const MerchantAdminDashboard: React.FC<{
  storeId: string;
  storeName?: string;
  samplePrintableOrder?: PrintableOrderRecord | null;
}> = ({ storeId, storeName = 'Crazy Cart', samplePrintableOrder = DEFAULT_PRINT_ORDER }) => {
  const [activeTab, setActiveTab] = useState<AdminTabKey>('settlement');
  const tabs: Array<{ key: AdminTabKey; label: string }> = [
    { key: 'settlement', label: 'Daily Settlement' },
    { key: 'manifest', label: 'Handover Manifest' },
    { key: 'returns', label: 'Return & Restock' },
    { key: 'fake_guard', label: 'Fake Order Guard' },
    { key: 'abandoned_crm', label: 'Abandoned CRM' },
    { key: 'courier_vault', label: 'Courier Vault' },
    { key: 'print_center', label: '80mm POS & 4×6 Label' },
  ];

  return (
    <div className="min-h-screen bg-slate-100/80 p-3 sm:p-6">
      <div className="mx-auto max-w-7xl space-y-5">
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-2xs sm:p-5">
          <div className="flex flex-col justify-between gap-2 sm:flex-row sm:items-center">
            <div>
              <span className="inline-flex rounded-full bg-indigo-50 px-2.5 py-0.5 text-[11px] font-bold text-indigo-700">
                Bangladesh D2C & F-Commerce • Asia/Dhaka (+06)
              </span>
              <h1 className="mt-1 text-xl font-black text-slate-900 sm:text-2xl">
                {storeName} Merchant Operations
              </h1>
            </div>
            <div className="font-mono text-xs font-semibold text-slate-500">Store ID: {storeId}</div>
          </div>

          <div className="mt-4 flex flex-wrap gap-2 border-t border-slate-100 pt-3.5">
            {tabs.map((t) => (
              <button
                key={t.key}
                type="button"
                onClick={() => setActiveTab(t.key)}
                className={`rounded-xl px-3.5 py-2 text-xs font-bold transition ${
                  activeTab === t.key ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>

        {activeTab === 'settlement' && <DailySettlementDashboard storeId={storeId} storeName={storeName} />}
        {activeTab === 'manifest' && <CarrierHandoverManifestConsole storeId={storeId} storeName={storeName} />}
        {activeTab === 'returns' && <CourierReturnRestockConsole storeId={storeId} storeName={storeName} />}
        {activeTab === 'fake_guard' && <FakeOrderReviewConsole storeId={storeId} storeName={storeName} />}
        {activeTab === 'abandoned_crm' && <AbandonedCartRecoveryConsole storeId={storeId} storeName={storeName} />}
        {activeTab === 'courier_vault' && <CourierCredentialsSettingsPanel storeId={storeId} storeName={storeName} />}
        {activeTab === 'print_center' && <PosAndLabelPrintSheet order={samplePrintableOrder ?? DEFAULT_PRINT_ORDER} storeName={storeName} />}
      </div>
    </div>
  );
};
